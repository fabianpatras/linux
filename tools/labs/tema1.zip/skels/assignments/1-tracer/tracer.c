// SPDX-License-Identifier: GPL-2.0+

#include <linux/kernel.h>
#include <linux/module.h>
#include <linux/miscdevice.h>
#include <linux/proc_fs.h> /* proc creation */
#include <linux/kprobes.h>
#include <linux/list.h>
#include <linux/slab.h> /* kmalloc, kfree */
#include <linux/seq_file.h> /* single_open */

#include "tracer.h"


MODULE_DESCRIPTION("Simple kernel timer");
MODULE_AUTHOR("SO2");
MODULE_LICENSE("GPL");

#define TRACER_PROC_NAME TRACER_DEV_NAME

#define PROC_TABLE_HEADER "PID   kmalloc kfree kmalloc_mem kfree_mem  sched   up     down  lock   unlock"
#define PROC_TABLE_LINE_LEN 128


enum {
	TRACER_UP = 0,
	TRACER_DOWN,
	TRACER_SCHEDULE,
	TRACER_MUTEX_LOCK,
	TRACER_MUTEX_UNLOCK,
	TRACER_KMALLOC,
	TRACER_KFREE,
	TRACER_NOP, // TODO: move me downwards
};

static char *tracer_function_names[] = {
	"up",
	"down_interruptible",
	"schedule",
	"mutex_lock_nested",
	"mutex_unlock",
	"__kmalloc",
	"kfree",
};


// ~~~ tracer proc ~~~
struct proc_dir_entry *proc_tracer;

struct proc_info_struct {
	pid_t pid;

	atomic_t kmalloc;
	atomic_t kfree;
	atomic_t kmalloc_mem;
	atomic_t kfree_mem;
	atomic_t sched;
	atomic_t up;
	atomic_t down;
	atomic_t lock;
	atomic_t unlock;

	struct list_head malloc_info_head;
	struct list_head list;
};

struct malloc_info {
	unsigned long addr;
	int size;

	struct list_head list;
};


// static LIST_HEAD(global_head);
static struct list_head global_head;
// TODO: add list lock


// ~~~ INTERNAL ~~~
static struct malloc_info *new_malloc_info(void)
{
	struct malloc_info *ptr = kmalloc(sizeof(struct malloc_info),
					  GFP_ATOMIC);

	if (!ptr)
		return NULL;

	memset(ptr, 0, sizeof(*ptr));

	INIT_LIST_HEAD(&ptr->list);

	return ptr;
}


static struct proc_info_struct *new_proc_info_struct(void)
{
	struct proc_info_struct *ptr = kmalloc(sizeof(struct proc_info_struct),
					       GFP_KERNEL);

	if (!ptr)
		return NULL;

	memset(ptr, 0, sizeof(*ptr));

	INIT_LIST_HEAD(&ptr->malloc_info_head);
	INIT_LIST_HEAD(&ptr->list);

	return ptr;
}

static int add_proc_to_global(pid_t pid)
{
	struct proc_info_struct *ptr = new_proc_info_struct();

	if (!ptr)
		return -ENOMEM;

	ptr->pid = pid;

	list_add_tail(&ptr->list, &global_head);

	return 0;
}

static int remove_proc_from_global(pid_t pid)
{
	struct list_head *pos, *q;
	struct proc_info_struct *proc_info;

	list_for_each_safe(pos, q, &global_head) {
		proc_info = container_of(pos, struct proc_info_struct, list);
		if (proc_info->pid == pid) {
			list_del(pos);
			kfree(proc_info);
			// TODO: free kmalloc list
		}
	}
	return 0;
}

// ~~~ KRETPROBES_HANDLERS ~~~


// ~~~ TRACER_UP ~~~
static int tracer_up_handler(struct kretprobe_instance *ri,
			     struct pt_regs *regs)
{
	struct list_head *pos, *q;
	struct proc_info_struct *proc_info;
	pid_t pid = current->pid;
	int counter = 0;

	list_for_each_safe(pos, q, &global_head) {
		proc_info = container_of(pos, struct proc_info_struct, list);
		if (proc_info->pid == pid) {
			atomic_inc(&proc_info->up);
			return 0;
		}
		counter++;
	}

	return -ESRCH; /* No such process */
}

// ~~~ TRACER_DOWN ~~~
static int tracer_down_handler(struct kretprobe_instance *ri,
			       struct pt_regs *regs)
{
	struct list_head *pos, *q;
	struct proc_info_struct *proc_info;
	pid_t pid = current->pid;

	list_for_each_safe(pos, q, &global_head) {
		proc_info = container_of(pos, struct proc_info_struct, list);
		if (proc_info->pid == pid) {
			atomic_inc(&proc_info->down);
			return 0;
		}
	}

	return -ESRCH; /* No such process */
}

// ~~~ SCHEDULE ~~~
static int tracer_schedule_handler(struct kretprobe_instance *ri,
				   struct pt_regs *regs)
{
	struct list_head *pos, *q;
	struct proc_info_struct *proc_info;
	pid_t pid = current->pid;

	list_for_each_safe(pos, q, &global_head) {
		proc_info = container_of(pos, struct proc_info_struct, list);
		if (proc_info->pid == pid) {
			atomic_inc(&proc_info->sched);
			return 0;
		}
	}

	return -ESRCH; /* No such process */
}

// ~~~ MUTEX_LOCK ~~~
static int tracer_mutex_lock_handler(struct kretprobe_instance *ri,
				     struct pt_regs *regs)
{
	struct list_head *pos, *q;
	struct proc_info_struct *proc_info;
	pid_t pid = current->pid;

	list_for_each_safe(pos, q, &global_head) {
		proc_info = container_of(pos, struct proc_info_struct, list);
		if (proc_info->pid == pid) {
			atomic_inc(&proc_info->lock);
			return 0;
		}
	}

	return -ESRCH; /* No such process */
}


// ~~~ MUTEX_UNLOCK ~~~
static int tracer_mutex_unlock_handler(struct kretprobe_instance *ri,
				       struct pt_regs *regs)
{
	struct list_head *pos, *q;
	struct proc_info_struct *proc_info;
	pid_t pid = current->pid;

	list_for_each_safe(pos, q, &global_head) {
		proc_info = container_of(pos, struct proc_info_struct, list);
		if (proc_info->pid == pid) {
			atomic_inc(&proc_info->unlock);
			return 0;
		}
	}

	return -ESRCH; /* No such process */
}

// ~~~ KMALLOC ~~~
static int tracer_kmalloc_handler(struct kretprobe_instance *ri,
				  struct pt_regs *regs)
{
	struct list_head *pos, *q;
	struct proc_info_struct *proc_info;
	pid_t pid = current->pid;

	struct malloc_info *malloc_info = (struct malloc_info *)ri->data;

	malloc_info->size = regs->ax;

	return 0; /* No such process */
}


static int tracer_kmalloc_ret_handler(struct kretprobe_instance *ri,
				      struct pt_regs *regs)
{
	struct list_head *pos, *q;
	struct proc_info_struct *proc_info;
	pid_t pid = current->pid;

	struct malloc_info *malloc_info = (struct malloc_info *)ri->data;

	// creating a persistent struct to add to list
	struct malloc_info *m_info = new_malloc_info();

	if (!m_info)
		return -ENOMEM;

	malloc_info->addr = regs_return_value(regs);

	memcpy(m_info, malloc_info, sizeof(*m_info));

	list_for_each_safe(pos, q, &global_head) {
		proc_info = container_of(pos, struct proc_info_struct, list);

		if (proc_info->pid == pid) {
			list_add_tail(&m_info->list,
				      &proc_info->malloc_info_head);
			atomic_inc(&proc_info->kmalloc);
			atomic_add(m_info->size, &proc_info->kmalloc_mem);
			return 0;
		}
	}

	return -ESRCH; /* No such process */
}

// ~~~ KFREE ~~~
static int tracer_kfree_handler(struct kretprobe_instance *ri,
				struct pt_regs *regs)
{
	struct list_head *pos, *q;
	struct list_head *pos2, *q2;
	struct proc_info_struct *proc_info;
	struct malloc_info *malloc_info;
	pid_t pid = current->pid;

	unsigned long free_addr = regs->ax;

	list_for_each_safe(pos, q, &global_head) {
		proc_info = container_of(pos, struct proc_info_struct, list);

		if (proc_info->pid == pid) {
			list_for_each_safe(pos2, q2,
					   &proc_info->malloc_info_head) {
				malloc_info = list_entry(pos2,
							 struct malloc_info,
							 list);

				if (malloc_info->addr == free_addr) {
					atomic_inc(&proc_info->kfree);
					atomic_add(malloc_info->size,
						   &proc_info->kfree_mem);

					// delete from list and from memory
					list_del(pos2);
					kfree(malloc_info);
					return 0;
				}
			}
		}
	}

	return -ESRCH; /* No such process */
}

// ~~~ KRETPROBES ~~~
static struct kretprobe tracer_krp[] = {
	// TRACER_UP
	{
		.entry_handler = tracer_up_handler,
		// .data_size = 32,
		.maxactive = 32
	},

	// TRACER_DOWN
	{
		.entry_handler = tracer_down_handler,
		// .data_size = 32,
		.maxactive = 32
	},

	// SCHEDULE
	{
		.entry_handler = tracer_schedule_handler,
		// .data_size = 32,
		.maxactive = 100
	},

	// MUTEX_LOCK
	{
		.entry_handler = tracer_mutex_lock_handler,
		// .data_size = 32,
		.maxactive = 32
	},

	// MUTEX_UNLOCK
	{
		.entry_handler = tracer_mutex_unlock_handler,
		// .data_size = 32,
		.maxactive = 32
	},

	// KMALLOC
	{
		.entry_handler = tracer_kmalloc_handler,
		.handler = tracer_kmalloc_ret_handler,
		.data_size = sizeof(struct malloc_info),
		.maxactive = 32
	},

	// KFREE
	{
		.entry_handler = tracer_kfree_handler,
		// .data_size = 32,
		.maxactive = 32
	},
};


// ~~~ /dev/tracer IOCTL FUNCTION ~~~
static long tracer_dev_ioctl(struct file *file,
			     unsigned int cmd, unsigned long arg)
{
	unsigned long pid = arg;
	int rc = 0;

	// pr_err(">\tAm intrat in tracer_dev_ioctl cu args cmd[%u] arg[%lu]\n",
	//        cmd, arg);

	switch (cmd) {
	case TRACER_ADD_PROCESS:

		rc = add_proc_to_global((pid_t) arg);
		if (rc)
			goto out;

		break;
	case TRACER_REMOVE_PROCESS:
		remove_proc_from_global(pid);
		break;
	default:
		pr_err("Unknown command [%d]\n", cmd);
		return -EINVAL;
	}

out:
	return rc;
}

// ~~~ /proc/tracer FUNCTIONS ~~~


static int tracer_proc_print(struct seq_file *m, void *v)
{
	struct list_head *pos, *q;
	struct proc_info_struct *proc_info;
	char buff[256];

	seq_puts(m, PROC_TABLE_HEADER "\n");
	// pr_err("%s", PROC_TABLE_HEADER "\n");

	list_for_each_safe(pos, q, &global_head) {
		proc_info = list_entry(pos, struct proc_info_struct, list);
		sprintf(buff,
			"%d %d %d %d %d %d %d %d %d %d\n",
			proc_info->pid,
			atomic_read(&proc_info->kmalloc),
			atomic_read(&proc_info->kfree),
			atomic_read(&proc_info->kmalloc_mem),
			atomic_read(&proc_info->kfree_mem),
			atomic_read(&proc_info->sched),
			atomic_read(&proc_info->up),
			atomic_read(&proc_info->down),
			atomic_read(&proc_info->lock),
			atomic_read(&proc_info->unlock));

		seq_puts(m, buff);

	}

	return 0;
}


static ssize_t tracer_proc_read(struct inode *inode, struct  file *file)
{
	return single_open(file, tracer_proc_print, NULL);
}

// ~~~ /dev/tracer I/O STRUCT DECLARAION ~~~
static const struct file_operations tracer_device_fops = {
	.unlocked_ioctl = tracer_dev_ioctl,
};

// ~~~ /proc/tracer I/O STRUCT DECLARAION ~~~
static const struct proc_ops tracer_proc_pops = {
	.proc_open = tracer_proc_read,
	.proc_read = seq_read,
	.proc_release = single_release
	// .proc_read = seq_read,
};

// ~~~ /dev/tracer STRUCT DECLARATION ~~~
static struct miscdevice tracer_dev = {
	.minor = TRACER_DEV_MINOR,
	.name = TRACER_DEV_NAME,
	.fops = &tracer_device_fops
};

// ~~~ MODEULE INIT / EXIT ~~~
static int __init tracer_init(void)
{
	int rc = 0;
	int no;
	int i;

	INIT_LIST_HEAD(&global_head);

	rc = misc_register(&tracer_dev);
	if (rc) {
		pr_err("Error on registering char device err[%d]\n", rc);
		goto err_ret;
	}

	// pr_info(">\tChar device [/dev/tracer] successfully initialized\n");
	proc_tracer = proc_create(TRACER_PROC_NAME, 0444, NULL,
				 &tracer_proc_pops);
	if (!proc_tracer) {
		pr_err("Error on creating /proc/tracer\n");
		goto misc_cleanup;
	}

	// pr_info(">\tProcess [/proc/tracer] successfully created\n");
	no = TRACER_NOP;
	// no = ARRAY_SIZE(tracer_krp);

	for (i = 0; i < no; i++) {
		tracer_krp[i].kp.symbol_name = tracer_function_names[i];
		rc = register_kretprobe(&tracer_krp[i]);
		if (rc) {
			pr_err("Error on register kretprobe for [%d]\n", i);
			no = i;
			goto proc_kret_cleanup;
		}
	}


	return 0;

proc_kret_cleanup:
	// this will leave rc = -ENOMEM
	for (i = 0; i < no; i++)
		unregister_kretprobe(&tracer_krp[i]);

	proc_remove(proc_tracer);

misc_cleanup:
	misc_deregister(&tracer_dev);
	rc = -ENOMEM; // idk?

err_ret:
	return rc;
}

static void __exit tracer_exit(void)
{
	int i;
	int no;

	// pr_info("\nStart of module exiting\n");
	misc_deregister(&tracer_dev);
	// pr_info(">\tChar device successfully deregistered\n");
	proc_remove(proc_tracer);
	// pr_info(">\tProc successfully removed\n");

	no = TRACER_NOP;
	// no = ARRAY_SIZE(tracer_krp);
	for (i = 0; i < no; i++)
		unregister_kretprobe(&tracer_krp[i]);
}

module_init(tracer_init);
module_exit(tracer_exit);
